<?php

/*
Plugin Name: Software Companey 
Plugin URI: https://wordpress.org/plugins/health-check/
Description: Softwate Companey Sidebar Section Add
Version: 0.1.0
Author: Prince
Author URI: http://health-check-team.example.com
Text Domain: health-check
Domain Path: /languages
*/

// software_slider_section Add 
function software_slider_section() {
    // slider custom post 
    $args =  array(
            'name'                  => _x( 'Sliders', 'Post type general name', 'CompaneyTextDomain' ),
            'singular_name'         => _x( 'Slider', 'Post type singular name', 'CompaneyTextDomain' ),
            'menu_name'             => _x( 'Sliders', 'Admin Menu text', 'CompaneyTextDomain' ),
            'name_admin_bar'        => _x( 'Slider', 'Add New on Toolbar', 'CompaneyTextDomain' ),
            'add_new'               => __( 'Add New', 'CompaneyTextDomain' ),
            'add_new_item'          => __( 'Add New Sliders', 'CompaneyTextDomain' ),
            'new_item'              => __( 'New Slider', 'CompaneyTextDomain' ),
            'edit_item'             => __( 'Edit Slider', 'CompaneyTextDomain' ),
            'view_item'             => __( 'View Slider', 'CompaneyTextDomain' ),
            'all_items'             => __( 'All Sliders', 'CompaneyTextDomain' ),
            'search_items'          => __( 'Search Slider', 'CompaneyTextDomain' ),
            'parent_item_colon'     => __( 'Parent Slider:', 'CompaneyTextDomain' ),
            'not_found'             => __( 'No Sliders found.', 'CompaneyTextDomain' ),
            'not_found_in_trash'    => __( 'No Sliders found in Trash.', 'CompaneyTextDomain' ),
            'featured_image'        => _x( 'Slider Cover Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', 'CompaneyTextDomain' ),
            'set_featured_image'    => _x( 'Set cover image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', 'CompaneyTextDomain' ),
            'remove_featured_image' => _x( 'Remove cover image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', 'CompaneyTextDomain' ),
            'use_featured_image'    => _x( 'Use as cover image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', 'CompaneyTextDomain' ),
            'archives'              => _x( 'Slider archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', 'CompaneyTextDomain' ),
            'insert_into_item'      => _x( 'Insert into Slider', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', 'CompaneyTextDomain' ),
            'uploaded_to_this_item' => _x( 'Uploaded to this Slider', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', 'CompaneyTextDomain' ),
            'filter_items_list'     => _x( 'Filter Sliders list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', 'CompaneyTextDomain' ),
            'items_list_navigation' => _x( 'Sliders list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', 'CompaneyTextDomain' ),
            'items_list'            => _x( 'Sliders list', 'Screen reader text for the items list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', 'CompaneyTextDomain' ),
       );
       $args = array(
            'labels'             => $args,
            'public'             => true,
            'publicly_queryable' => true,
            'show_ui'            => true,
            'show_in_menu'       => true,
            'query_var'          => true,
            'rewrite'            => array( 'slug' => 'sliderAdd' ),
            'capability_type'    => 'post',
            'has_archive'        => true,
            'hierarchical'       => false,
            'menu_position'      => null,
            'supports'           => array( 'title', 'thumbnail', 'custom-fields' ),
            'menu_icon'          => 'dashicons-products',
	);
    register_post_type( 'sliderAdd', $args );

    // Services Custom Post 
     $args =  array(
        'name'                  => _x( 'Services', 'Post type general name', 'CompaneyTextDomain' ),
        'singular_name'         => _x( 'Service', 'Post type singular name', 'CompaneyTextDomain' ),
        'menu_name'             => _x( 'Services', 'Admin Menu text', 'CompaneyTextDomain' ),
        'name_admin_bar'        => _x( 'Service', 'Add New on Toolbar', 'CompaneyTextDomain' ),
        'add_new'               => __( 'Add New', 'CompaneyTextDomain' ),
        'add_new_item'          => __( 'Add New Services', 'CompaneyTextDomain' ),
        'new_item'              => __( 'New Service', 'CompaneyTextDomain' ),
        'edit_item'             => __( 'Edit Service', 'CompaneyTextDomain' ),
        'view_item'             => __( 'View Service', 'CompaneyTextDomain' ),
        'all_items'             => __( 'All Service', 'CompaneyTextDomain' ),
        'search_items'          => __( 'Search Service', 'CompaneyTextDomain' ),
        'parent_item_colon'     => __( 'Parent Service:', 'CompaneyTextDomain' ),
        'not_found'             => __( 'No Service found.', 'CompaneyTextDomain' ),
        'not_found_in_trash'    => __( 'No Service found in Trash.', 'CompaneyTextDomain' ),
   );
   $args = array(
        'labels'             => $args,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'Services' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'custom-fields' ),
        'menu_icon'          => 'dashicons-shield',
);
register_post_type( 'Services', $args );

    // Prices Custom Post 
     $args =  array(
        'name'                  => _x( 'Prices List', 'Post type general name', 'CompaneyTextDomain' ),
        'singular_name'         => _x( 'Price', 'Post type singular name', 'CompaneyTextDomain' ),
        'menu_name'             => _x( 'Prices', 'Admin Menu text', 'CompaneyTextDomain' ),
        'name_admin_bar'        => _x( 'Price', 'Add New on Toolbar', 'CompaneyTextDomain' ),
        'add_new'               => __( 'Add New', 'CompaneyTextDomain' ),
        'add_new_item'          => __( 'Add New Prices', 'CompaneyTextDomain' ),
        'new_item'              => __( 'New Price', 'CompaneyTextDomain' ),
        'edit_item'             => __( 'Edit Price', 'CompaneyTextDomain' ),
        'view_item'             => __( 'View Price', 'CompaneyTextDomain' ),
        'all_items'             => __( 'All Price', 'CompaneyTextDomain' ),
        'search_items'          => __( 'Search Price', 'CompaneyTextDomain' ),
        'parent_item_colon'     => __( 'Parent Price:', 'CompaneyTextDomain' ),
        'not_found'             => __( 'No Price found.', 'CompaneyTextDomain' ),
        'not_found_in_trash'    => __( 'No Price found in Trash.', 'CompaneyTextDomain' ),
   );
   $args = array(
        'labels'             => $args,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'Prices' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title', 'editor', 'custom-fields' ),
        'menu_icon'          => 'dashicons-image-rotate-left',
);
register_post_type( 'Prices', $args );
    
    // Testimonial Custom Post 
    $args =  array(
        'name'                  => _x( 'Testimonial List', 'Post type general name', 'CompaneyTextDomain' ),
        'singular_name'         => _x( 'Testimonial', 'Post type singular name', 'CompaneyTextDomain' ),
        'menu_name'             => _x( 'Testimonials', 'Admin Menu text', 'CompaneyTextDomain' ),
        'name_admin_bar'        => _x( 'Testimonial', 'Add New on Toolbar', 'CompaneyTextDomain' ),
        'add_new'               => __( 'Add New', 'CompaneyTextDomain' ),
        'add_new_item'          => __( 'Add New Prices', 'CompaneyTextDomain' ),
        'new_item'              => __( 'New Testimonial', 'CompaneyTextDomain' ),
        'edit_item'             => __( 'Edit Testimonial', 'CompaneyTextDomain' ),
        'view_item'             => __( 'View Testimonial', 'CompaneyTextDomain' ),
        'all_items'             => __( 'All Testimonial', 'CompaneyTextDomain' ),
        'search_items'          => __( 'Search Testimonial', 'CompaneyTextDomain' ),
        'parent_item_colon'     => __( 'Parent Testimonial:', 'CompaneyTextDomain' ),
        'not_found'             => __( 'No Testimonial found.', 'CompaneyTextDomain' ),
        'not_found_in_trash'    => __( 'No Testimonial found in Trash.', 'CompaneyTextDomain' ),
    );
    $args = array(
        'labels'             => $args,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'Testimonial' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title' ),
        'menu_icon'          => 'dashicons-testimonial',
    );
    register_post_type( 'Testimonial', $args );


    // Team Members Custom Post 
    $args =  array(
        'name'                  => _x( 'Team Members List', 'Post type general name', 'CompaneyTextDomain' ),
        'singular_name'         => _x( 'Team Member', 'Post type singular name', 'CompaneyTextDomain' ),
        'menu_name'             => _x( 'Team Members', 'Admin Menu text', 'CompaneyTextDomain' ),
        'name_admin_bar'        => _x( 'Team Member', 'Add New on Toolbar', 'CompaneyTextDomain' ),
        'add_new'               => __( 'Add New', 'CompaneyTextDomain' ),
        'add_new_item'          => __( 'Add New Team Members', 'CompaneyTextDomain' ),
        'new_item'              => __( 'New Team Member', 'CompaneyTextDomain' ),
        'edit_item'             => __( 'Edit Team Member', 'CompaneyTextDomain' ),
        'view_item'             => __( 'View Team Member', 'CompaneyTextDomain' ),
        'all_items'             => __( 'All Team Member', 'CompaneyTextDomain' ),
        'search_items'          => __( 'Search Team Member', 'CompaneyTextDomain' ),
        'parent_item_colon'     => __( 'Parent Team Member:', 'CompaneyTextDomain' ),
        'not_found'             => __( 'No Team Member found.', 'CompaneyTextDomain' ),
        'not_found_in_trash'    => __( 'No Team Member found in Trash.', 'CompaneyTextDomain' ),
    );
    $args = array(
        'labels'             => $args,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => array( 'slug' => 'Team Members' ),
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => null,
        'supports'           => array( 'title' ),
        'menu_icon'          => 'dashicons-image-filter',
    );
    register_post_type( 'TeamMember', $args );

}
add_action( 'init', 'software_slider_section' );
